function show_value2(x)
{

 if(x<196) {    
    sisa_spin = 200-x;
    jumlah_spin = Math.ceil(sisa_spin/5);
    yz = jumlah_spin*270; 
}

if(x>195) { 
    sisa_spin = 200-x;
    yz = sisa_spin*60;
}
 
 document.getElementById("slider_value2").innerHTML=yz;
}

var slideCol = document.getElementById("myRange");
var y = document.getElementById("f");
y.innerHTML = slideCol.value;

slideCol.oninput = function() {
    y.innerHTML = this.value;
}