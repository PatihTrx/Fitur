function show_value2(x) {

    if(x<90){    
       yz = Math.ceil((2000 - x * 20) * 850 / 1000); 
   }
   if(x>89){ 
       yz = Math.ceil((2000 - x * 20));
   }
   
    document.getElementById("slider_value2").innerHTML=yz;
    
   }

var slideCol = document.getElementById("myRange");
var y = document.getElementById("f");
y.innerHTML = slideCol.value;

slideCol.oninput = function() {
    y.innerHTML = this.value;
}